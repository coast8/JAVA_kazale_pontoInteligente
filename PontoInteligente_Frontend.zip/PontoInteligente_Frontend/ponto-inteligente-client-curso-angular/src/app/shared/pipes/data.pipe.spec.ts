import { DataPipe } from './data.pipe';

describe('DataPipe', () => {
  it('create an instance', () => {
    const pipe = new DataPipe();
    expect(pipe).toBeTruthy();
  });
});
