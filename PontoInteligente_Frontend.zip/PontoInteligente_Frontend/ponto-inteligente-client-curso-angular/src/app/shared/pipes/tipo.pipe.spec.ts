import { TipoPipe } from './tipo.pipe';

describe('TipoPipe', () => {
  it('create an instance', () => {
    const pipe = new TipoPipe();
    expect(pipe).toBeTruthy();
  });
});
