export * from './atualizacao.component';
