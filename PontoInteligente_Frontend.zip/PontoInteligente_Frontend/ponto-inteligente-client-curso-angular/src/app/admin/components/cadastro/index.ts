export * from './cadastro.component';
